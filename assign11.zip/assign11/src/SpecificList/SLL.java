package SpecificList;
import java.util.Scanner;
import Common.CommonList;

class Node{
	public int data;
	public Node next;
	
	public Node(){
		data = 0;
		next = null;
	}
	
	public Node(int x){
		data = x;
		next = null;
	} 
}

public class SLL implements CommonList {

	Node head;
	
	SLL(){
		head = null;
	}
	
	public void create(int data){
		Node new1 = new Node(data);
		if(head == null){
			head = new1;
		}
		else{
			Node temp = new Node();
			temp = head;
			
			while(temp.next != null)
				temp = temp.next;
			
			temp.next = new1;
			new1.next = null;
		}
	}
	
	public void insert(int x) {
		Scanner s = new Scanner(System.in);
		System.out.println("Select position ");
		int pos = s.nextInt();
		int cnt = size();
		Node new1 = new Node(x);
		
		if(pos == 1){
			new1.next = head;
			head = new1;
		}
		else if(pos < cnt+1){
			Node temp = new Node();
			temp = head;
			
			while(pos != 2){
				temp = temp.next;
				pos--;
			}
			
			new1.next = temp.next;
			temp.next = new1;
		}
		else {
			Node temp = new Node();
			temp = head;
			
			while(temp.next != null)
				temp = temp.next;
			
			temp.next = new1;
			new1.next = null;
		}
	}

	public void display() {
		Node temp = new Node();
		temp = head;
		
		while(temp.next != null){
			System.out.print(temp.data +" --> ");
			temp = temp.next;
		}
		System.out.println(temp.data);
	}

	public boolean isEmpty() {
		if(head == null)
			return true ;
		else
			return false;
	}

	public int size() {
		Node temp = new Node();
		temp = head;
		int count = 0;
		
		while(temp != null){
			count++;
			temp = temp.next;
		}
		return count;
	}

	public void remove() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter element to be removed ");
		int data = s.nextInt();
		
		Node temp1 = new Node();
		temp1 = head;
		Node temp2 = new Node();
		temp2 = null;
		
		if(head.data == data){
			head = temp1.next;
			temp1.next = null;
		}
		else{
			while(temp1.data != data){
				temp2 = temp1;
				temp1 = temp1.next;
			}	
			temp2.next = temp1.next;
			temp1.next = null;
		}
	}
		
		
	public void search() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter data to be searched ");
		int data = s.nextInt();
		int flag = 0;
		
		Node temp = new Node();
		temp = head;
		
		while(temp != null){
			if(temp.data == data){
				flag = 1;
				break;
			}
		}
		
		if(flag == 1)
			System.out.println("FOUND ");
		else
			System.out.println("NOT FOUND ");
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		SLL list = new SLL();
		int cho;
		
		do{
			System.out.println("========================");
			System.out.println("Select an operation     ");
			System.out.println("1. Create a SLL         ");
			System.out.println("2. Add new element      ");
			System.out.println("3. Remove an element    ");
			System.out.println("4. Display SLL          ");
			System.out.println("5. Check if empty       ");
			System.out.println("6. Size of SLL          ");
			System.out.println("7. Search for a element ");
			System.out.println("8. EXIT                 ");
			System.out.println("========================");
			cho = s.nextInt();
			
			switch(cho){
			case 1:
			{
				int n, data;
				System.out.print("Enter number of terms : ");
				n = s.nextInt();
				
				for(int i=0;i<n;i++){
					System.out.print("\nData :");
					data = s.nextInt();
					list.create(data);
				}
			}
			break;
			
			case 2:
			{
				int data;
				System.out.print("Data :");
				data = s.nextInt();
				list.insert(data);
			}
			break;
			
			case 3:
				list.remove();
				break;
				
			case 4:
				list.display();
				break;
				
			case 5:
				if(list.isEmpty())
					System.out.println("List is empty ");
				else
					System.out.println("List is not empty ");
				
				break;
				
			case 6:
				int size = list.size();
				System.out.println("Size of SLL is "+ size);
				break;
				
			case 7:
				list.search();
				break;
				
			case 8:
				System.out.println("Terminating !! ");
				break;
				
			default:
				System.out.println("Select a valid option ");
				break;
			}
			
		}while(cho != 8);
	}
}
