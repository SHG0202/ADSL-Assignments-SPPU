package Common;

public interface CommonList {
	void create(int data);
	void insert(int x);
    void display();
    boolean isEmpty();
    int size();
    void remove();
    void search();

}
